create definer = root@localhost view v_stocks as
select `sales`.`product`.`productNo`   AS `productNo`,
       `sales`.`product`.`productName` AS `productName`,
       `sales`.`product`.`categoryId`  AS `categoryId`,
       `sales`.`product`.`price`       AS `price`,
       `sales`.`product`.`stocks`      AS `stocks`
from `sales`.`product`
where (`sales`.`product`.`stocks` < 500);

-- comment on column v_stocks.productNo not supported: 商品编号

-- comment on column v_stocks.productName not supported: 商品名称

-- comment on column v_stocks.categoryId not supported: 商品种类ID

-- comment on column v_stocks.price not supported: 单价

-- comment on column v_stocks.stocks not supported: 库存量

