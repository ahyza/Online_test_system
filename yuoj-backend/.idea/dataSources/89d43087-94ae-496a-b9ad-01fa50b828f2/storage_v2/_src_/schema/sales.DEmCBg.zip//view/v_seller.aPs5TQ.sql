create definer = root@localhost view v_seller as
select `sales`.`seller`.`saleNo`   AS `saleNo`,
       `sales`.`seller`.`saleName` AS `saleName`,
       `sales`.`seller`.`sex`      AS `sex`,
       `sales`.`seller`.`address`  AS `address`
from `sales`.`seller`;

-- comment on column v_seller.saleNo not supported: 销售员编号

-- comment on column v_seller.saleName not supported: 销售员姓名

-- comment on column v_seller.sex not supported: 性别

-- comment on column v_seller.address not supported: 地址

