create definer = root@localhost view v_sale_total as
select `p`.`id`                             AS `id`,
       sum(`od`.`quantity`)                 AS `saleQuantity`,
       sum((`od`.`quantity` * `p`.`price`)) AS `saleTotal`
from (`sales`.`orderdetail` `od` join `sales`.`product` `p` on ((`od`.`productId` = `p`.`id`)))
group by `p`.`id`;

-- comment on column v_sale_total.id not supported: 商品ID

